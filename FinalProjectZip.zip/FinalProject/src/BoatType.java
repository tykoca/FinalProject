/**
 * Enum representing the type of a boat.
 */
public enum BoatType {
    SAILING,
    POWER
}
